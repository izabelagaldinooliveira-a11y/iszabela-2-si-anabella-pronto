# meu-projeto-v2
Projeto destinado a pratica de atributos de inclusão
